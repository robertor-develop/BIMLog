// ── Login.tsx ─────────────────────────────────────────────────────────────
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useI18n } from "@/lib/i18n";
import { useAuthStore } from "@/store/auth";
import { useLogin } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { AlertCircle } from "lucide-react";

export function Login() {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const { login } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const { mutate, isPending } = useLogin({
    mutation: {
      onSuccess: (data) => {
        login(data.token, data.user);
        setLocation('/dashboard');
      },
      onError: () => setError(t('auth.loginFailed'))
    }
  });

  return (
    <AuthLayout
      title="Welcome back"
      subtitle="Sign in to your BIMLog account"
      footer={<>{t('auth.noAccount')} <Link href="/register" className="text-primary font-medium hover:underline">{t('auth.register')}</Link></>}
    >
      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/20 text-destructive text-sm mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.email')}</label>
          <Input
            type="email"
            placeholder="you@company.com"
            value={email}
            onChange={e => { setEmail(e.target.value); setError(''); }}
            autoComplete="email"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.password')}</label>
          <Input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={e => { setPassword(e.target.value); setError(''); }}
            autoComplete="current-password"
          />
        </div>
      </div>

      <Button
        className="w-full mt-6"
        disabled={!email || !password || isPending}
        onClick={() => mutate({ data: { email, password } })}
      >
        {isPending ? 'Signing in...' : t('auth.login')}
      </Button>
    </AuthLayout>
  );
}

// ── Register.tsx ───────────────────────────────────────────────────────────
export function Register() {
  const { t } = useI18n();
  const [, setLocation] = useLocation();
  const { login } = useAuthStore();
  const [form, setForm] = useState({ email: '', password: '', fullName: '', companyName: '' });
  const [error, setError] = useState('');

  const { mutate, isPending } = useRegister({
    mutation: {
      onSuccess: (data) => {
        login(data.token, data.user);
        setLocation('/dashboard');
      },
      onError: () => setError(t('auth.registerFailed'))
    }
  });

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [k]: e.target.value });
    setError('');
  };

  return (
    <AuthLayout
      title="Create your account"
      subtitle="Start coordinating better with BIMLog"
      footer={<>{t('auth.hasAccount')} <Link href="/login" className="text-primary font-medium hover:underline">{t('auth.login')}</Link></>}
    >
      {error && (
        <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/5 border border-destructive/20 text-destructive text-sm mb-4">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          {error}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.fullName')}</label>
          <Input placeholder="Roberto Rodriguez" value={form.fullName} onChange={set('fullName')} autoComplete="name" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.companyName')}</label>
          <Input placeholder="BIMtech Corp" value={form.companyName} onChange={set('companyName')} autoComplete="organization" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.email')}</label>
          <Input type="email" placeholder="you@company.com" value={form.email} onChange={set('email')} autoComplete="email" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">{t('auth.password')}</label>
          <Input type="password" placeholder="••••••••" value={form.password} onChange={set('password')} autoComplete="new-password" />
        </div>
      </div>

      <Button
        className="w-full mt-6"
        disabled={!form.email || !form.password || !form.fullName || !form.companyName || isPending}
        onClick={() => mutate({ data: form })}
      >
        {isPending ? 'Creating account...' : t('auth.register')}
      </Button>
    </AuthLayout>
  );
}

// ── Shared auth layout ─────────────────────────────────────────────────────
function AuthLayout({
  title, subtitle, footer, children
}: {
  title: string;
  subtitle: string;
  footer: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-[calc(100vh-56px)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-sm">

        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-12 h-12 rounded-xl bg-primary flex items-center justify-center mx-auto mb-5">
            <span className="font-display font-bold text-white text-lg">B</span>
          </div>
          <h1 className="font-display font-bold text-foreground text-2xl">{title}</h1>
          <p className="text-muted-foreground text-sm mt-1.5">{subtitle}</p>
        </div>

        {/* Card */}
        <div className="card p-6">
          {children}
        </div>

        {/* Footer */}
        <p className="text-center text-sm text-muted-foreground mt-5">{footer}</p>
      </div>
    </div>
  );
}

// ── useRegister hook shim (mirrors useLogin pattern) ──────────────────────
import { useRegister } from "@workspace/api-client-react";
